/**
 * GadgetVilla Dashboard - Google Apps Script Web App (Data Layer)
 * ----------------------------------------------------------------
 * doGet  : READ  - returns every sheet in the bound Spreadsheet as JSON,
 *                  keyed by the sheet (tab) name. Each tab -> array of row
 *                  objects using the first row as column headers.
 * doPost : WRITE - Admin CRUD (create / update / delete). Provided now so the
 *                  front-end can Sync back to Google Sheets in the next phase.
 *
 * SECURITY: an optional shared token can be required. Set it in Script
 * Properties (key: API_TOKEN). If empty, no token is enforced. The token is
 * NEVER hardcoded here.
 *
 * Deploy: Deploy > New deployment > Web app > Execute as "Me" >
 *         Who has access: "Anyone". Copy the /exec URL into config.js.
 */

function _token_() {
  return PropertiesService.getScriptProperties().getProperty('API_TOKEN') || '';
}

function _checkToken_(provided) {
  var expected = _token_();
  if (!expected) return true;            // no token configured -> open
  return provided === expected;
}

function _json_(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

/** Read one sheet into an array of {header: value} row objects. */
function _readSheet_(sheet) {
  var values = sheet.getDataRange().getValues();
  if (!values || values.length < 2) return [];
  var headers = values[0].map(function (h) { return String(h).trim(); });
  var rows = [];
  for (var r = 1; r < values.length; r++) {
    var row = values[r];
    // skip fully empty rows
    var empty = row.every(function (c) { return c === '' || c === null; });
    if (empty) continue;
    var obj = {};
    for (var c = 0; c < headers.length; c++) {
      if (!headers[c]) continue;
      obj[headers[c]] = row[c];
    }
    rows.push(obj);
  }
  return rows;
}

/** GET -> { ok:true, data: { tabName: [ {..row..}, ... ], ... } } */
function doGet(e) {
  try {
    var token = (e && e.parameter && e.parameter.token) || '';
    if (!_checkToken_(token)) {
      return _json_({ ok: false, error: 'unauthorized' });
    }
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var sheets = ss.getSheets();
    var data = {};
    for (var i = 0; i < sheets.length; i++) {
      var name = sheets[i].getName();
      data[name] = _readSheet_(sheets[i]);
    }
    return _json_({ ok: true, data: data });
  } catch (err) {
    return _json_({ ok: false, error: String(err) });
  }
}

/**
 * POST -> Admin CRUD. Body (text/plain JSON to avoid CORS preflight):
 *   { token, sheet, action: 'create'|'update'|'delete', row, match }
 *   - create: appends `row` (object keyed by header)
 *   - update: updates first row where every key in `match` equals; sets `row`
 *   - delete: deletes first row where every key in `match` equals
 * Returns { ok:true, ... } or { ok:false, error }.
 */
function doPost(e) {
  try {
    var body = {};
    if (e && e.postData && e.postData.contents) {
      body = JSON.parse(e.postData.contents);
    }
    if (!_checkToken_(body.token || '')) {
      return _json_({ ok: false, error: 'unauthorized' });
    }
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var sheet = ss.getSheetByName(body.sheet);
    if (!sheet) return _json_({ ok: false, error: 'sheet not found: ' + body.sheet });

    var values = sheet.getDataRange().getValues();
    var headers = (values[0] || []).map(function (h) { return String(h).trim(); });
    var colIndex = {};
    headers.forEach(function (h, i) { colIndex[h] = i; });

    function rowMatches(rowValues, match) {
      return Object.keys(match || {}).every(function (k) {
        return colIndex[k] !== undefined &&
               String(rowValues[colIndex[k]]) === String(match[k]);
      });
    }

    if (body.action === 'create') {
      var newRow = headers.map(function (h) {
        return (body.row && body.row[h] !== undefined) ? body.row[h] : '';
      });
      sheet.appendRow(newRow);
      return _json_({ ok: true, action: 'create' });
    }

    if (body.action === 'update') {
      for (var r = 1; r < values.length; r++) {
        if (rowMatches(values[r], body.match)) {
          headers.forEach(function (h, c) {
            if (body.row && body.row[h] !== undefined) {
              sheet.getRange(r + 1, c + 1).setValue(body.row[h]);
            }
          });
          return _json_({ ok: true, action: 'update', rowNumber: r + 1 });
        }
      }
      return _json_({ ok: false, error: 'no matching row' });
    }

    if (body.action === 'delete') {
      for (var r2 = 1; r2 < values.length; r2++) {
        if (rowMatches(values[r2], body.match)) {
          sheet.deleteRow(r2 + 1);
          return _json_({ ok: true, action: 'delete', rowNumber: r2 + 1 });
        }
      }
      return _json_({ ok: false, error: 'no matching row' });
    }

    return _json_({ ok: false, error: 'unknown action: ' + body.action });
  } catch (err) {
    return _json_({ ok: false, error: String(err) });
  }
}

/**
 * GadgetVilla Dashboard - runtime configuration.
 * This file is git-ignored (see .gitignore). Do NOT commit real URLs/tokens.
 *
 * HOW TO USE
 *   1) Deploy Code.gs as a Web App and copy the /exec URL below.
 *   2) (optional) If you set a Script Property API_TOKEN in Apps Script,
 *      put the same value in `token` below.
 *   3) Set `useLive` to true to read data from Google Sheets.
 *      Set it to false to fall back to the built-in data in the dashboard.
 */
window.GV_CONFIG = {
  // Paste your Apps Script Web App URL here (ends with /exec). Leave "" to disable.
  webAppUrl: "",

  // Optional shared token. Leave "" if you did not set API_TOKEN in Apps Script.
  token: "",

  // Feature toggle: true = use live Google Sheets data, false = use built-in fallback.
  useLive: false
};
